// 'use strict';
// eslint-disable-next-line @typescript-eslint/no-var-requires
const mix = require('laravel-mix');
// eslint-disable-next-line @typescript-eslint/no-var-requires
const path = require('path');

const publicAssetsFolder = path.join(__dirname, '..', 'public');

// Styles
// mix.postCss('resources/css/site.css', publicAssetsFolder + '/css')

// Vue apps
mix.js('src/main.jsx', publicAssetsFolder + '/js').react();

// React apps
// mix.js('resources/js/react/apps/auth/auth.js', publicAssetsFolder + '/js/apps')
//    .react();
// .postCss('resources/css/apps/auth/auth.css', publicAssetsFolder + '/css/apps/auth');

mix.copyDirectory('public', publicAssetsFolder);
// mix.copyDirectory('resources/fonts', publicAssetsFolder + '/fonts');
// mix.copyDirectory('resources/img', publicAssetsFolder + '/img');

// mix.browserSync('localhost:7085');

mix.options({
  postCss: [require('tailwindcss')],
});

module.exports = mix; // Ensure you export mix if necessary
